# My Health — Android + Health Connect

Personal health app prototype for Android. UI language: Azerbaijani. Palette: white, beige and sage green.

## Health Connect integration

This project includes Health Connect step-count reading:
- Declares `android.permission.health.READ_STEPS`.
- Checks Health Connect availability.
- Requests the user's explicit read permission.
- Reads today's total using `StepsRecord.COUNT_TOTAL` aggregation (avoids double-counting multiple data sources).
- Shows the latest total in the home dashboard and provides a refresh button.

The app does not connect to a phone from the development environment. Install the built APK on the Android device, tap **Health Connect-i qoş**, and approve the step permission in the system dialog. The user can revoke access at any time in Health Connect settings.

On Android 14 and later, Health Connect is part of the system. On Android 13 and earlier, install/update the Health Connect app from Google Play. Availability requires Android 9+ and Google Play services.

## Build requirements

- Android Studio with Android SDK Platform 36
- Android Gradle Plugin 8.9.1+
- Gradle 8.11.1+
- JDK 17

Open this folder in Android Studio, allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important

This is an early prototype, not a medically validated product. The Health Connect integration is source-code implemented but must be built and tested on a physical Android device. Only step-count read access is requested. Health data is sensitive; the app should be reviewed and tested before storing real medical records or publishing it.
