# My Health APK-ni telefondan buludda yaratmaq

Bu layihəyə GitHub Actions build workflow-u əlavə olunub. GitHub hesabı ilə mənbə kodunu şəxsi/public repository-yə yüklədikdən sonra APK buludda kompilyasiya edilə bilər.

1. Chrome-da https://github.com/new açın və yeni repository yaradın (məsələn, `my-health-android`).
2. ZIP-i telefona endirib fayl menecerində çıxarın. `MyHealth` qovluğunun İÇİNDƏKİ bütün fayl və qovluqları repository-nin kökünə yükləyin; `.github` qovluğunun gizli olmadığını və workflow faylının da yükləndiyini yoxlayın.
3. Repository-də **Actions** bölməsini açın. GitHub Actions üçün istənilən təsdiq sorğusunu qəbul edin.
4. **Build My Health APK** workflow-unu seçin və **Run workflow** düyməsinə basın.
5. Build uğurlu bitdikdə həmin run səhifəsinin **Artifacts** hissəsindən `MyHealth-debug-apk` faylını endirin.
6. ZIP artifact-i çıxarın və `app-debug.apk` faylını açaraq Android quraşdırma icazəsini verin.

Qeyd: GitHub hesabı tələb olunur. Repository-ni şəxsi (Private) saxlamaq tibbi layihə mənbəyinin məxfiliyi üçün daha münasibdir. GitHub Actions build-i yalnız APK yaradır; APK-nı telefonda quraşdırıb Health Connect icazəsini ayrıca verməlisiniz.

## Build tələbləri
- JDK 17
- Android SDK Platform 36 və Build Tools 36.0.0
- Gradle 8.11.1

## Məhdudiyyətlər
Bu, erkən prototipdir. Health Connect addım oxuma kodu daxil edilib, lakin fiziki cihazda yoxlanılmayıb. Tibbi sənədlər və real sağlamlıq məlumatları üçün istifadə etməzdən əvvəl təhlükəsizlik və funksionallıq testləri aparılmalıdır.
