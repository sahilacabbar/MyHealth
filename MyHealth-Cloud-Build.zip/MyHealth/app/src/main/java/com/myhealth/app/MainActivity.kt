package com.myhealth.app

import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.aggregate.AggregateRequest
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Sage = Color(0xFF71866B)
private val Pale = Color(0xFFF1F3EA)
private val Cream = Color(0xFFFAF8F1)
private val Ink = Color(0xFF30382F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyHealthApp(this) }
    }
}

@Composable
fun MyHealthApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("my_health_private", Context.MODE_PRIVATE) }
    var water by remember { mutableIntStateOf(prefs.getInt("water", 0)) }
    var note by remember { mutableStateOf(prefs.getString("note", "") ?: "") }
    var periodDate by remember { mutableStateOf(prefs.getString("period", "") ?: "") }
    var tab by remember { mutableStateOf("Ana səhifə") }
    var steps by remember { mutableLongStateOf(0L) }
    var healthConnectStatus by remember { mutableStateOf("Addımlar Health Connect vasitəsilə oxunacaq.") }
    var healthConnectReady by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val stepPermission = remember { HealthPermission.getReadPermission(StepsRecord::class) }
    val stepsPermissionLauncher = rememberLauncherForActivityResult(
        contract = PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        if (stepPermission in granted) {
            scope.launch {
                runCatching { readTodaySteps(context) }
                    .onSuccess { steps = it; healthConnectStatus = "Health Connect ilə sinxronlaşdırıldı."; healthConnectReady = true }
                    .onFailure { healthConnectStatus = "Addım məlumatını oxumaq mümkün olmadı: ${it.localizedMessage ?: "xəta"}" }
            }
        } else {
            healthConnectStatus = "Addım məlumatlarına icazə verilmədi. İstədiyin vaxt qoşa bilərsən."
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Sage, background = Cream, surface = Color.White)) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf("Ana səhifə" to Icons.Default.Home, "Təqvim" to Icons.Default.CalendarMonth, "Arxiv" to Icons.Default.FolderOpen, "Mən" to Icons.Default.Person)
                    items.forEach { (label, icon) ->
                        NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("MY HEALTH", color = Sage, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text(when(tab) { "Təqvim" -> "Sağlamlıq təqvimi"; "Arxiv" -> "Tibbi arxiv"; "Mən" -> "Şəxsi profil"; else -> "Salam!" }, color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(color = Pale, shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.Favorite, null, tint = Sage, modifier = Modifier.padding(13.dp)) }
                }
                Spacer(Modifier.height(20.dp))
                when(tab) {
                    "Ana səhifə" -> {
                        Surface(color = Pale, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp)) {
                                Text("Şəxsi sağlamlıq panelin", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                Text("Kiçik gündəlik addımlar böyük fərq yaradır.", color = Sage, fontSize = 13.sp)
                                Spacer(Modifier.height(18.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    MetricCard("Su", "$water / 8", Icons.Default.WaterDrop, Modifier.weight(1f))
                                    MetricCard("Addımlar", if (healthConnectReady) String.format("%,d", steps) else "Qoşulmayıb", Icons.Default.DirectionsWalk, Modifier.weight(1f))
                                }
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { water = (water + 1).coerceAtMost(30); prefs.edit().putInt("water", water).apply() }, colors = ButtonDefaults.buttonColors(containerColor = Sage), modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("1 stəkan su içdim")
                                }
                                TextButton(onClick = { water = 0; prefs.edit().putInt("water", 0).apply() }) { Text("Gündəlik sayğacı sıfırla", color = Sage) }
                                Spacer(Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            when (HealthConnectClient.getSdkStatus(context)) {
                                                HealthConnectClient.SDK_AVAILABLE -> {
                                                    val client = HealthConnectClient.getOrCreate(context)
                                                    val granted = client.permissionController.getGrantedPermissions()
                                                    if (stepPermission in granted) {
                                                        runCatching { readTodaySteps(context) }
                                                            .onSuccess { steps = it; healthConnectReady = true; healthConnectStatus = "Health Connect ilə sinxronlaşdırıldı." }
                                                            .onFailure { healthConnectStatus = "Oxuma xətası: ${it.localizedMessage ?: "naməlum xəta"}" }
                                                    } else {
                                                        stepsPermissionLauncher.launch(setOf(stepPermission))
                                                    }
                                                }
                                                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                                                    healthConnectStatus = "Health Connect tətbiqini yenilə və yenidən cəhd et."
                                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.healthdata"))) }
                                                }
                                                else -> healthConnectStatus = "Bu cihazda Health Connect mövcud deyil. Android 9 və ya daha yeni versiya tələb olunur."
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Sage)
                                ) {
                                    Icon(Icons.Default.Sync, null); Spacer(Modifier.width(8.dp)); Text(if (healthConnectReady) "Addımları yenilə" else "Health Connect-i qoş")
                                }
                                Text(healthConnectStatus, color = Sage, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        SectionTitle("Sürətli giriş")
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FeatureCard("Menstrual dövr", Icons.Default.CalendarMonth, Modifier.weight(1f))
                            FeatureCard("Dərmanlar", Icons.Default.Medication, Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FeatureCard("Analizlər", Icons.Default.Description, Modifier.weight(1f))
                            FeatureCard("AI köməkçi", Icons.Default.AutoAwesome, Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(18.dp))
                        SectionTitle("Gündəlik qeydim")
                        OutlinedTextField(value = note, onValueChange = { note = it; prefs.edit().putString("note", it).apply() }, modifier = Modifier.fillMaxWidth(), minLines = 3, placeholder = { Text("Bu gün özünü necə hiss edirsən?") }, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Sage, unfocusedBorderColor = Pale))
                    }
                    "Təqvim" -> {
                        InfoCard("Menstrual dövr", "Son menstruasiyanın ilk gününü qeyd et. Bu məlumat cihazında saxlanılır.")
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(value = periodDate, onValueChange = { periodDate = it; prefs.edit().putString("period", it).apply() }, modifier = Modifier.fillMaxWidth(), label = { Text("Son menstruasiyanın ilk günü") }, placeholder = { Text("Məsələn: 2026-11-01") })
                        Text("Tarixi YYYY-AA-GG formatında yaz. Dövr proqnozu hələ aktiv deyil.", color = Sage, fontSize = 12.sp)
                    }
                    "Arxiv" -> {
                        InfoCard("Tibbi sənədlər", "Burada analizlər, reseptlər, USM nəticələri və həkim qeydləri üçün arxiv bölməsi yaradılacaq.")
                        InfoCard("Növbəti inkişaf", "Fayl və foto əlavə etmək, tarix və kateqoriya üzrə axtarış.")
                    }
                    else -> {
                        InfoCard("Şəxsi profil", "Bu bölmədə şəxsi məlumatlar, allergiyalar, qan qrupu, həkimlər və tibbi tarixçə saxlanacaq.")
                        InfoCard("Məxfilik", "Bu ilkin versiyada qeydlər telefonun tətbiq yaddaşında saxlanılır. Telefonun ekran kilidini aktiv saxla.")
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("My Health • İlkin prototip", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable fun MetricCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) { Icon(icon, null, tint = Sage); Spacer(Modifier.height(8.dp)); Text(title, color = Color.Gray, fontSize = 12.sp); Text(value, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
    }
}
@Composable fun FeatureCard(title: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = modifier) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Sage); Spacer(Modifier.width(9.dp)); Text(title, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium) } }
}
@Composable fun SectionTitle(text: String) { Text(text, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 10.dp)) }
@Composable fun InfoCard(title: String, body: String) { Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { Column(Modifier.padding(18.dp)) { Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp); Spacer(Modifier.height(6.dp)); Text(body, color = Color.Gray, fontSize = 13.sp) } } }


private suspend fun readTodaySteps(context: Context): Long {
    val client = HealthConnectClient.getOrCreate(context)
    val zone = ZoneId.systemDefault()
    val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
    val end = Instant.now()
    val response = client.aggregate(
        AggregateRequest(
            metrics = setOf(StepsRecord.COUNT_TOTAL),
            timeRangeFilter = TimeRangeFilter.between(start, end)
        )
    )
    return response[StepsRecord.COUNT_TOTAL] ?: 0L
}
