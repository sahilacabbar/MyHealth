package com.myhealth.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.view.Gravity

class HealthConnectRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val message = TextView(this).apply {
            text = "My Health addım sayını göstərmək üçün Health Connect-dən yalnız addım məlumatlarını oxuyur. Məlumatlar reklam üçün istifadə edilmir və tətbiq daxilində şəxsi sağlamlıq panelində göstərilir. İcazəni istənilən vaxt telefonunun Health Connect ayarlarından geri ala bilərsən."
            textSize = 17f
            setPadding(48, 48, 48, 48)
            gravity = Gravity.CENTER
        }
        setContentView(message)
    }
}
